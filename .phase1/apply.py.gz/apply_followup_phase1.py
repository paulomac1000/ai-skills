from __future__ import annotations

import importlib.util
import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
MCP = ROOT / "skills/mcp-server-architect"
TOOLS = MCP / "tools"


def read(path: str | Path) -> str:
    return (ROOT / path).read_text(encoding="utf-8") if isinstance(path, str) else path.read_text(encoding="utf-8")


def write(path: str | Path, content: str) -> None:
    target = ROOT / path if isinstance(path, str) else path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content.rstrip() + "\n", encoding="utf-8", newline="\n")


def replace_once(path: str | Path, old: str, new: str) -> None:
    target = ROOT / path if isinstance(path, str) else path
    text = target.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{target}: expected one occurrence, found {count}: {old[:100]!r}")
    target.write_text(text.replace(old, new), encoding="utf-8", newline="\n")


def append_once(path: str | Path, marker: str, block: str) -> None:
    target = ROOT / path if isinstance(path, str) else path
    text = target.read_text(encoding="utf-8")
    if block.strip() in text:
        return
    if marker not in text:
        raise RuntimeError(f"{target}: append marker missing: {marker!r}")
    target.write_text(text.replace(marker, marker + block, 1), encoding="utf-8", newline="\n")


# Load the current public generator before replacing either module. It resolves the
# existing facade patches once and gives us the exact reviewed output to migrate
# into a single canonical template directory.
spec = importlib.util.spec_from_file_location("legacy_public_generator", TOOLS / "generate_python_server.py")
assert spec and spec.loader
legacy = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = legacy
spec.loader.exec_module(legacy)
seed_package = "canonical_mcp"
seed_server = "Canonical MCP"
files: dict[str, str] = legacy.project_files(seed_package, seed_server)

MANIFEST_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/paulomac1000/ai-skills/raw/main/contracts/mcp-capability-manifest.schema.json",
    "title": "MCP capability manifest",
    "type": "object",
    "additionalProperties": False,
    "required": [
        "name", "version", "risk", "side_effects", "confidentiality", "impact",
        "determinism", "latency", "cost", "reversible", "idempotent",
        "idempotency_mechanism", "retryable", "retry_conditions",
        "concurrent_safe", "concurrency_scope", "max_concurrency_per_scope",
        "max_concurrency_global", "timeout_ms", "max_response_bytes",
        "requires_confirmation", "target_binding", "active_state",
    ],
    "properties": {
        "name": {"type": "string", "pattern": "^[a-z][a-z0-9_]{1,63}$"},
        "version": {"type": "string", "pattern": "^[0-9]+[.][0-9]+[.][0-9]+$"},
        "risk": {"enum": ["read", "write", "destructive", "dangerous", "sensitive"]},
        "side_effects": {"enum": ["none", "read", "write", "destructive"]},
        "confidentiality": {"enum": ["public", "internal", "personal", "sensitive", "credential", "financial"]},
        "impact": {"enum": ["none", "transient", "persistent", "service_outage", "financial", "physical", "safety_critical"]},
        "determinism": {"enum": ["deterministic", "probabilistic", "environment_dependent", "eventually_consistent"]},
        "latency": {"enum": ["low", "medium", "high", "long_running"]},
        "cost": {"enum": ["low", "medium", "high", "abuse_sensitive"]},
        "reversible": {"type": "boolean"},
        "idempotent": {"type": "boolean"},
        "idempotency_mechanism": {"type": ["string", "null"], "maxLength": 256},
        "retryable": {"type": "boolean"},
        "retry_conditions": {"type": "array", "items": {"type": "string", "minLength": 1}, "uniqueItems": True},
        "concurrent_safe": {"type": "boolean"},
        "concurrency_scope": {"enum": ["none", "global", "principal", "target", "credential", "resource", "custom"]},
        "max_concurrency_per_scope": {"type": "integer", "minimum": 1, "maximum": 10000},
        "max_concurrency_global": {"type": "integer", "minimum": 1, "maximum": 10000},
        "timeout_ms": {"type": "integer", "minimum": 100, "maximum": 3600000},
        "max_response_bytes": {"type": "integer", "minimum": 1024, "maximum": 16777216},
        "requires_confirmation": {"type": "boolean"},
        "target_binding": {"type": "string", "minLength": 1, "maxLength": 512},
        "active_state": {"enum": ["active", "disabled", "degraded", "unavailable", "deprecated"]},
    },
}
schema_text = json.dumps(MANIFEST_SCHEMA, indent=2, sort_keys=True) + "\n"
write("contracts/mcp-capability-manifest.schema.json", schema_text)

MANIFESTS_PY = '''\
"""Application-owned manifests governed by the canonical ai-skills schema."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from importlib.resources import files
from typing import Literal

Risk = Literal["read", "write", "destructive", "dangerous", "sensitive"]
SideEffects = Literal["none", "read", "write", "destructive"]
Confidentiality = Literal["public", "internal", "personal", "sensitive", "credential", "financial"]
Impact = Literal["none", "transient", "persistent", "service_outage", "financial", "physical", "safety_critical"]
Determinism = Literal["deterministic", "probabilistic", "environment_dependent", "eventually_consistent"]
Latency = Literal["low", "medium", "high", "long_running"]
Cost = Literal["low", "medium", "high", "abuse_sensitive"]
ConcurrencyScope = Literal["none", "global", "principal", "target", "credential", "resource", "custom"]
ActiveState = Literal["active", "disabled", "degraded", "unavailable", "deprecated"]

@dataclass(frozen=True, slots=True)
class CapabilityManifest:
    name: str
    version: str
    risk: Risk
    side_effects: SideEffects
    confidentiality: Confidentiality
    impact: Impact
    determinism: Determinism
    latency: Latency
    cost: Cost
    reversible: bool
    idempotent: bool
    idempotency_mechanism: str | None
    retryable: bool
    retry_conditions: tuple[str, ...]
    concurrent_safe: bool
    concurrency_scope: ConcurrencyScope
    max_concurrency_per_scope: int
    max_concurrency_global: int
    timeout_ms: int
    max_response_bytes: int
    requires_confirmation: bool
    target_binding: str
    active_state: ActiveState = "active"

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


def _read(name: str, confidentiality: Confidentiality, target: str) -> CapabilityManifest:
    return CapabilityManifest(
        name=name,
        version="1.0.0",
        risk="read",
        side_effects="read",
        confidentiality=confidentiality,
        impact="none",
        determinism="deterministic",
        latency="low",
        cost="low",
        reversible=True,
        idempotent=True,
        idempotency_mechanism="natural read",
        retryable=False,
        retry_conditions=(),
        concurrent_safe=True,
        concurrency_scope="none",
        max_concurrency_per_scope=32,
        max_concurrency_global=64,
        timeout_ms=5_000,
        max_response_bytes=262_144,
        requires_confirmation=False,
        target_binding=target,
    )

MANIFESTS = {
    "describe_capabilities": _read("describe_capabilities", "public", "capability catalog"),
    "get_health": _read("get_health", "internal", "process runtime"),
    "list_items": _read("list_items", "internal", "process inventory"),
    "put_item": CapabilityManifest(
        name="put_item",
        version="1.0.0",
        risk="write",
        side_effects="write",
        confidentiality="internal",
        impact="persistent",
        determinism="deterministic",
        latency="low",
        cost="low",
        reversible=True,
        idempotent=False,
        idempotency_mechanism="mandatory expected_version precondition",
        retryable=False,
        retry_conditions=(),
        concurrent_safe=False,
        concurrency_scope="resource",
        max_concurrency_per_scope=1,
        max_concurrency_global=8,
        timeout_ms=5_000,
        max_response_bytes=262_144,
        requires_confirmation=True,
        target_binding="stable item_id plus mandatory expected_version",
    ),
}


def schema() -> dict[str, object]:
    resource = files(__package__).joinpath("mcp-capability-manifest.schema.json")
    return json.loads(resource.read_text(encoding="utf-8"))


def validate_manifest(manifest: CapabilityManifest) -> None:
    required = set(schema()["required"])
    values = manifest.as_dict()
    if set(values) != required:
        raise RuntimeError(f"manifest schema drift for {manifest.name}: {sorted(set(values) ^ required)}")
    if manifest.timeout_ms < 100 or manifest.max_response_bytes < 1_024:
        raise RuntimeError(f"invalid bounds for {manifest.name}")
    if manifest.retryable and (not manifest.idempotent or not manifest.retry_conditions):
        raise RuntimeError(f"retryable capability lacks idempotency and retry conditions: {manifest.name}")
    if manifest.concurrent_safe is False and manifest.concurrency_scope == "none":
        raise RuntimeError(f"unsafe capability lacks concurrency scope: {manifest.name}")
    if manifest.concurrent_safe is False and manifest.concurrency_scope == "global" and manifest.max_concurrency_per_scope != 1:
        raise RuntimeError(f"global unsafe capability must serialize: {manifest.name}")
    if manifest.max_concurrency_per_scope > manifest.max_concurrency_global:
        raise RuntimeError(f"per-scope concurrency exceeds global limit: {manifest.name}")
    if manifest.side_effects == "destructive" and not manifest.requires_confirmation:
        raise RuntimeError(f"destructive capability must require confirmation: {manifest.name}")


def validate_manifests(registered_names: set[str]) -> None:
    missing = registered_names - set(MANIFESTS)
    orphaned = set(MANIFESTS) - registered_names
    if missing or orphaned:
        raise RuntimeError(f"manifest coverage mismatch: missing={sorted(missing)}, orphaned={sorted(orphaned)}")
    for manifest in MANIFESTS.values():
        validate_manifest(manifest)
'''
files[f"src/{seed_package}/manifests.py"] = MANIFESTS_PY
files[f"src/{seed_package}/mcp-capability-manifest.schema.json"] = schema_text

# Package the schema with the wheel.
files["pyproject.toml"] += f'''\n[tool.setuptools.package-data]\n{seed_package} = ["mcp-capability-manifest.schema.json"]\n'''

# Replace the old bool-active, lock-only, and pre-envelope response handling with
# canonical active state, explicit concurrency limits, and final serialized limits.
kernel_key = f"src/{seed_package}/kernel.py"
kernel = files[kernel_key]
kernel = kernel.replace("import asyncio\n", "import asyncio\nimport json\n")
kernel = kernel.replace(
    'self._locks: dict[str, asyncio.Lock] = {}',
    'self._scope_gates: dict[str, asyncio.Semaphore] = {}\n        self._global_gates: dict[str, asyncio.Semaphore] = {}',
)
kernel = kernel.replace(
    'return {name for name, manifest in MANIFESTS.items() if manifest.active}',
    'return {name for name, manifest in MANIFESTS.items() if manifest.active_state == "active"}',
)
kernel = kernel.replace(
    'lock = self._lock_for(manifest, arguments)\n            async with asyncio.timeout(seconds):\n                if lock is None:\n                    data = await self._handlers[name](arguments)\n                else:\n                    async with lock:\n                        data = await self._handlers[name](arguments)\n            return {"success": True, "data": data, "_meta": {"request_id": request_id, "target_id": caller.target_id, "duration_ms": int((time.monotonic() - started) * 1000)}}',
    'scope_gate, global_gate = self._gates_for(manifest, arguments, caller)\n            async with asyncio.timeout(seconds):\n                async with global_gate:\n                    async with scope_gate:\n                        data = await self._handlers[name](arguments)\n            response = {"success": True, "data": data, "_meta": {"request_id": request_id, "target_id": caller.target_id, "duration_ms": int((time.monotonic() - started) * 1000)}}\n            return self._bounded_response(response, manifest)',
)
kernel = kernel.replace(
    'if manifest is None or not manifest.active or name not in self._handlers:',
    'if manifest is None or manifest.active_state != "active" or name not in self._handlers:',
)
old_lock = '''\
    def _lock_for(self, manifest: CapabilityManifest, arguments: dict[str, Any]) -> asyncio.Lock | None:
        if manifest.concurrent_safe:
            return None
        return self._locks.setdefault(str(arguments.get("item_id") or manifest.concurrency_scope), asyncio.Lock())
'''
new_lock = '''\
    def _gates_for(
        self,
        manifest: CapabilityManifest,
        arguments: dict[str, Any],
        caller: CallerContext,
    ) -> tuple[asyncio.Semaphore, asyncio.Semaphore]:
        if manifest.concurrency_scope == "resource":
            scope_key = f"resource:{arguments.get('item_id', '')}"
        elif manifest.concurrency_scope == "principal":
            scope_key = f"principal:{caller.principal}"
        elif manifest.concurrency_scope == "target":
            scope_key = f"target:{caller.target_id}"
        else:
            scope_key = manifest.concurrency_scope
        scope_gate = self._scope_gates.setdefault(
            f"{manifest.name}:{scope_key}", asyncio.Semaphore(manifest.max_concurrency_per_scope)
        )
        global_gate = self._global_gates.setdefault(
            manifest.name, asyncio.Semaphore(manifest.max_concurrency_global)
        )
        return scope_gate, global_gate

    @staticmethod
    def _bounded_response(response: dict[str, Any], manifest: CapabilityManifest) -> dict[str, Any]:
        encoded = json.dumps(response, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(encoded) <= manifest.max_response_bytes:
            return response
        meta = response.get("_meta", {})
        return {
            "success": False,
            "error": {
                "code": "RESPONSE_TOO_LARGE",
                "message": "final serialized response exceeds capability limit",
                "retryable": False,
            },
            "_meta": meta,
        }
'''
if old_lock not in kernel:
    raise RuntimeError("legacy lock block not found")
kernel = kernel.replace(old_lock, new_lock)
files[kernel_key] = kernel

# Real installed-entrypoint and transport tests emitted into every generated repo.
files["tests/test_process_transport_smoke.py"] = f'''\
from __future__ import annotations

import os
import socket
import subprocess
import sys
import time

import pytest
from mcp import ClientSession, StdioServerParameters
from mcp.client import Client
from mcp.client.stdio import stdio_client


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _wait_for_port(port: int, process: subprocess.Popen[str]) -> None:
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        if process.poll() is not None:
            stdout, stderr = process.communicate(timeout=2)
            raise AssertionError(f"server exited early\\nstdout={{stdout}}\\nstderr={{stderr}}")
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return
        except OSError:
            time.sleep(0.1)
    raise AssertionError("HTTP server did not become reachable")


@pytest.mark.anyio
async def test_installed_entrypoint_stdio_lists_calls_and_fails_closed() -> None:
    location = subprocess.run(
        [sys.executable, "-c", "import {seed_package}, pathlib; print(pathlib.Path({seed_package}.__file__).resolve())"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert "site-packages" in location or "dist-packages" in location
    parameters = StdioServerParameters(command=sys.executable, args=["-m", "{seed_package}"])
    async with stdio_client(parameters) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            tools = await session.list_tools()
            assert "list_items" in {{tool.name for tool in tools.tools}}
            result = await session.call_tool("list_items", {{"limit": 1}})
            assert result.is_error is not True
            denied = await session.call_tool(
                "put_item", {{"item_id": "blocked", "name": "Blocked", "expected_version": 0}}
            )
            assert denied.is_error is True


@pytest.mark.anyio
async def test_installed_entrypoint_streamable_http_lists_calls_and_fails_closed() -> None:
    port = _free_port()
    environment = os.environ.copy()
    environment.update({{"MCP_TRANSPORT": "streamable-http", "MCP_HOST": "127.0.0.1", "MCP_PORT": str(port)}})
    process = subprocess.Popen(
        [sys.executable, "-m", "{seed_package}"],
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    try:
        _wait_for_port(port, process)
        async with Client(f"http://127.0.0.1:{{port}}/mcp", raise_exceptions=True) as client:
            listed = await client.list_tools()
            assert "list_items" in {{tool.name for tool in listed.tools}}
            result = await client.call_tool("list_items", {{"limit": 1}})
            assert result.is_error is not True
            denied = await client.call_tool(
                "put_item", {{"item_id": "blocked", "name": "Blocked", "expected_version": 0}}
            )
            assert denied.is_error is True
    finally:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
'''

files["tests/smoke_exact_container.py"] = f'''\
from __future__ import annotations

import asyncio
import socket
import subprocess
import sys
import time
import uuid

from mcp import ClientSession, StdioServerParameters
from mcp.client import Client
from mcp.client.stdio import stdio_client


async def smoke_stdio(image: str) -> None:
    parameters = StdioServerParameters(command="docker", args=["run", "--rm", "-i", image])
    async with stdio_client(parameters) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            tools = await session.list_tools()
            assert "list_items" in {{tool.name for tool in tools.tools}}
            result = await session.call_tool("list_items", {{"limit": 1}})
            assert result.is_error is not True
            denied = await session.call_tool(
                "put_item", {{"item_id": "blocked", "name": "Blocked", "expected_version": 0}}
            )
            assert denied.is_error is True


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


async def smoke_http(image: str) -> None:
    name = "mcp-smoke-" + uuid.uuid4().hex[:12]
    port = _free_port()
    subprocess.run(
        [
            "docker", "run", "--rm", "--detach", "--name", name, "--network", "host",
            "-e", "MCP_TRANSPORT=streamable-http", "-e", "MCP_HOST=127.0.0.1",
            "-e", f"MCP_PORT={{port}}", image,
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    try:
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                    break
            except OSError:
                time.sleep(0.1)
        else:
            logs = subprocess.run(["docker", "logs", name], capture_output=True, text=True).stdout
            raise AssertionError(f"container HTTP server did not start: {{logs}}")
        async with Client(f"http://127.0.0.1:{{port}}/mcp", raise_exceptions=True) as client:
            listed = await client.list_tools()
            assert "list_items" in {{tool.name for tool in listed.tools}}
            result = await client.call_tool("list_items", {{"limit": 1}})
            assert result.is_error is not True
    finally:
        subprocess.run(["docker", "rm", "--force", name], check=False, capture_output=True, text=True)


async def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: smoke_exact_container.py IMAGE")
    await smoke_stdio(sys.argv[1])
    await smoke_http(sys.argv[1])


if __name__ == "__main__":
    asyncio.run(main())
'''

# Generated workflow: same auditor contract as adoption repos, concrete runner,
# explicit concurrency, and exact-container stdio + HTTP smoke.
workflow = files[".github/workflows/ci.yml"]
if not workflow.startswith("# ai-skills-policy-profile:"):
    workflow = "# ai-skills-policy-profile: trusted-ci\n" + workflow
workflow = workflow.replace("runs-on: ubuntu-latest", "runs-on: ubuntu-24.04")
workflow = workflow.replace(
    "permissions:\n  contents: read\n\njobs:",
    "permissions:\n  contents: read\n\nconcurrency:\n  group: generated-mcp-${{ github.workflow }}-${{ github.ref }}\n  cancel-in-progress: true\n\njobs:",
)
needle = '''\
      - name: Verify container wheel identity
        shell: bash
        run: |
          LABEL=$(docker inspect --format '{{ index .Config.Labels "org.opencontainers.image.source-wheel-sha256" }}' generated-mcp:ci)
          test "$LABEL" = "${{ steps.wheel.outputs.sha256 }}"
'''
replacement = needle + '''\
      - name: Smoke exact container over stdio and Streamable HTTP
        run: python tests/smoke_exact_container.py generated-mcp:ci
'''
if needle not in workflow:
    raise RuntimeError("generated workflow container identity step missing")
workflow = workflow.replace(needle, replacement)
files[".github/workflows/ci.yml"] = workflow
files[".github/workflow-policy.yaml"] = "schema_version: 1\nworkflows:\n  .github/workflows/ci.yml: trusted-ci\n"

# Update generated manifest tests.
files["tests/test_manifests.py"] = f'''\
from {seed_package}.manifests import MANIFESTS, schema, validate_manifests
from {seed_package}.server import REGISTERED_TOOLS


def test_manifest_coverage_schema_and_conservative_write_defaults() -> None:
    validate_manifests(REGISTERED_TOOLS)
    assert set(MANIFESTS) == REGISTERED_TOOLS
    assert set(schema()["required"]) == set(MANIFESTS["put_item"].as_dict())
    write = MANIFESTS["put_item"]
    assert write.idempotent is False
    assert write.retryable is False
    assert write.concurrent_safe is False
    assert write.concurrency_scope == "resource"
    assert write.max_concurrency_per_scope == 1
    assert write.max_response_bytes >= 1024
    assert "mandatory expected_version" in str(write.idempotency_mechanism)
'''

# Materialize one canonical template tree. Locks remain canonical under locks/ and
# are copied directly by the generator; every other emitted file lives here once.
template_root = TOOLS / "python-template"
if template_root.exists():
    shutil.rmtree(template_root)
lock_names = set(legacy.LOCK_NAMES)
source_names = set(legacy.SOURCE_NAMES)
for relative, content in sorted(files.items()):
    if relative.startswith("requirements/") and Path(relative).name in lock_names | source_names:
        continue
    rendered_path = relative.replace(seed_package, "__PACKAGE__") + ".template"
    rendered_content = content.replace(seed_package, "__PACKAGE__").replace(seed_server, "__SERVER_NAME__")
    write(template_root / rendered_path, rendered_content)

IMPL = '''\
#!/usr/bin/env python3
"""Canonical template-backed generator for a production-oriented Python MCP server."""

from __future__ import annotations

import argparse
import ctypes
import errno
import keyword
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path

PACKAGE_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
SERVER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._-]{1,79}$")
RESERVED_PACKAGE_NAMES = frozenset(
    set(getattr(sys, "stdlib_module_names", ()))
    | {"mcp", "uvicorn", "pytest", "build", "setuptools", "wheel"}
)
LOCK_ROOT = Path(__file__).resolve().parents[1] / "locks"
TEMPLATE_ROOT = Path(__file__).resolve().with_name("python-template")
LOCK_IDS = (
    "linux-x64-py312", "linux-x64-py313", "linux-x64-py314",
    "macos-arm64-py312", "windows-x64-py312",
)
LOCK_NAMES = tuple(
    f"{kind}-{identifier}.lock" for kind in ("runtime", "dev") for identifier in LOCK_IDS
)
SOURCE_NAMES = ("python-runtime.in", "python-dev.in")
_AT_FDCWD = -100
_RENAME_NOREPLACE = 1
_RENAME_EXCL = 0x00000004


def _validate(package: str, server_name: str) -> None:
    if not PACKAGE_RE.fullmatch(package) or keyword.iskeyword(package) or package in RESERVED_PACKAGE_NAMES:
        raise ValueError("package must be a non-reserved snake_case identifier with 2-64 characters")
    if not SERVER_RE.fullmatch(server_name):
        raise ValueError("server name must contain 2-80 safe display characters")


def _render(value: str, package: str, server_name: str) -> str:
    return value.replace("__PACKAGE__", package).replace("__SERVER_NAME__", server_name)


def project_files(package: str, server_name: str) -> dict[str, str]:
    """Render every project file from the canonical final template tree and lock graph."""
    _validate(package, server_name)
    result: dict[str, str] = {}
    for template in sorted(TEMPLATE_ROOT.rglob("*.template")):
        relative = template.relative_to(TEMPLATE_ROOT).as_posix().removesuffix(".template")
        path = _render(relative, package, server_name)
        result[path] = _render(template.read_text(encoding="utf-8"), package, server_name)
    for name in (*LOCK_NAMES, *SOURCE_NAMES):
        result[f"requirements/{name}"] = (LOCK_ROOT / name).read_text(encoding="utf-8")
    return result


def _raise_rename_error(error_number: int, destination: Path) -> None:
    if error_number in {errno.EEXIST, errno.ENOTEMPTY}:
        raise FileExistsError(error_number, "generation target already exists", destination)
    raise OSError(error_number, os.strerror(error_number), destination)


def _runtime_platform() -> str:
    return sys.platform


def _runtime_os_name() -> str:
    return os.name


def _rename_noreplace(source: Path, destination: Path) -> None:
    source_bytes = os.fsencode(source)
    destination_bytes = os.fsencode(destination)
    platform_name = _runtime_platform()
    if platform_name.startswith("linux"):
        libc = ctypes.CDLL(None, use_errno=True)
        renameat2 = getattr(libc, "renameat2", None)
        if renameat2 is None:
            raise RuntimeError("atomic no-replace rename requires renameat2 on Linux")
        renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        renameat2.restype = ctypes.c_int
        if renameat2(_AT_FDCWD, source_bytes, _AT_FDCWD, destination_bytes, _RENAME_NOREPLACE) != 0:
            _raise_rename_error(ctypes.get_errno(), destination)
        return
    if platform_name == "darwin":
        libc = ctypes.CDLL(None, use_errno=True)
        renamex_np = getattr(libc, "renamex_np", None)
        if renamex_np is None:
            raise RuntimeError("atomic no-replace rename requires renamex_np on macOS")
        renamex_np.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_uint]
        renamex_np.restype = ctypes.c_int
        if renamex_np(source_bytes, destination_bytes, _RENAME_EXCL) != 0:
            _raise_rename_error(ctypes.get_errno(), destination)
        return
    if _runtime_os_name() == "nt":
        os.rename(source, destination)
        return
    raise RuntimeError("this platform has no configured atomic no-replace directory rename")


def generate_project(target: Path, package: str, server_name: str) -> list[Path]:
    expanded = target.expanduser()
    target = expanded.parent.resolve(strict=False) / expanded.name
    target.parent.mkdir(parents=True, exist_ok=True)
    if os.path.lexists(target):
        raise FileExistsError(errno.EEXIST, "generation target already exists", target)
    files = project_files(package, server_name)
    staging = Path(tempfile.mkdtemp(prefix=f".{target.name}-", dir=target.parent))
    published = False
    try:
        for relative, content in sorted(files.items()):
            destination = staging / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(content, encoding="utf-8", newline="\\n")
        _rename_noreplace(staging, target)
        published = True
        return [Path(relative) for relative in sorted(files)]
    finally:
        if not published:
            shutil.rmtree(staging, ignore_errors=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", type=Path, help="new project directory; must not exist")
    parser.add_argument("--package", required=True)
    parser.add_argument("--name", required=True, dest="server_name")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    created = generate_project(args.target, args.package, args.server_name)
    print(f"Generated {len(created)} files in {args.target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
'''
write(TOOLS / "generate_python_server_impl.py", IMPL)

FACADE = '''\
#!/usr/bin/env python3
"""Public entry point for the canonical Python MCP project generator."""

from __future__ import annotations

import importlib.util
from pathlib import Path

_IMPL = Path(__file__).with_name("generate_python_server_impl.py")
_spec = importlib.util.spec_from_file_location("mcp_python_generator_impl", _IMPL)
if _spec is None or _spec.loader is None:
    raise RuntimeError(f"cannot load generator implementation: {_IMPL}")
_impl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_impl)
_implementation = _impl

PACKAGE_RE = _impl.PACKAGE_RE
SERVER_RE = _impl.SERVER_RE
RESERVED_PACKAGE_NAMES = _impl.RESERVED_PACKAGE_NAMES
LOCK_IDS = _impl.LOCK_IDS
LOCK_NAMES = _impl.LOCK_NAMES
SOURCE_NAMES = _impl.SOURCE_NAMES
project_files = _impl.project_files
generate_project = _impl.generate_project
main = _impl.main

__all__ = [
    "PACKAGE_RE", "SERVER_RE", "RESERVED_PACKAGE_NAMES", "LOCK_IDS", "LOCK_NAMES",
    "SOURCE_NAMES", "project_files", "generate_project", "main",
]

if __name__ == "__main__":
    raise SystemExit(main())
'''
write(TOOLS / "generate_python_server.py", FACADE)

# Rename the misleading official-SDK profile and add a separate external FastMCP profile.
old_profile = MCP / "references/python-fastmcp.md"
new_profile = MCP / "references/python-official-mcp-sdk.md"
if old_profile.exists():
    text = old_profile.read_text(encoding="utf-8")
    text = text.replace("# Python and FastMCP", "# Python official MCP SDK")
    new_profile.write_text(text, encoding="utf-8", newline="\n")
    old_profile.unlink()
for path in ROOT.rglob("*.md"):
    text = path.read_text(encoding="utf-8")
    updated = text.replace("references/python-fastmcp.md", "references/python-official-mcp-sdk.md")
    updated = updated.replace("[Python and FastMCP]", "[Python official MCP SDK]")
    if updated != text:
        path.write_text(updated, encoding="utf-8", newline="\n")

FAST_MCP_PROFILE = '''\
---
description: Implementation profile for the separately distributed FastMCP Python package.
doc_id: reference.mcp-python-fastmcp-package
type: reference
status: active
rigor: operational
owners: [repository-maintainers]
verification:
  kind: ci-job
  value: Route a fixture repository by package and imports, then run auth-context, middleware, principal-overlap, transport, and public-registration tests against its pinned FastMCP version.
---

# Python FastMCP package profile

## Scope

This profile applies only when the dependency is the separately distributed `fastmcp` package and imports originate from `fastmcp`. It does not apply to `mcp`, `mcp.server.mcpserver`, or historical `mcp.server.fastmcp` namespaces from the official SDK.

Record the exact package name, resolved version, import paths, registration API, transport factory, auth provider, middleware hooks, and task backend before changing code. FastMCP-specific middleware is an implementation mechanism, not an MCP protocol feature.

## Required routing evidence

An assessment records one of these values:

- `python-official-mcp-sdk` for package `mcp` and official SDK imports;
- `python-fastmcp-package` for package `fastmcp` and `fastmcp` imports;
- `unsupported-sdk-profile` when package/import/API evidence does not match a supported profile.

`unsupported-sdk-profile` blocks an unqualified L2+ conformance claim. Migration may continue only with an owned waiver, explicit SDK-isolation boundary, upstream API tests, and no invented private-registry contract.

## Principal and authorization flow

For Streamable HTTP, authenticate through a supported `AuthProvider`. Normalize the request-scoped `AccessToken`/`AuthContext` into the application-owned `CallerContext`; never create one process-wide principal for network clients. Authorization middleware may reject visibility or invocation, but every tool still delegates to the shared invocation kernel for resource and target authorization.

Test two overlapping clients with different token subjects, scopes, targets, and downstream credentials. Each invocation must retain its own principal through middleware, task creation, kernel execution, audit records, and downstream calls. Stdio has no OAuth bearer context; the embedding host must provide an explicit local principal contract instead of silently reusing the HTTP path.

## Middleware and public APIs

Use documented `FastMCP`, `Context`, auth-check, provider, transform, and middleware APIs for the pinned version. Treat request context as optional during initialization phases. Do not use internal registries, mutate private request fields, forward inbound authorization headers to unrelated downstreams, or infer future compatibility from a similarly named class in the official SDK.

## Required regressions

- malformed, empty, oversized, non-ASCII, duplicate, and wrong-scheme authorization headers fail as controlled authentication errors;
- absent request context during initialization does not create an anonymous privileged principal;
- component visibility and kernel authorization agree;
- principal overlap remains isolated;
- background tasks remain bound to the originating authorization context;
- stdio and Streamable HTTP use the same manifest and invocation kernel;
- exact installed package and deployment artifact pass official-client listing, call, failure, and shutdown tests.
'''
write(MCP / "references/python-fastmcp-package.md", FAST_MCP_PROFILE)

ROUTING = '''\
---
description: Deterministic SDK profile selection for MCP server assessments and migrations.
doc_id: reference.mcp-sdk-profile-routing
type: reference
status: active
rigor: operational
owners: [repository-maintainers]
verification:
  kind: command
  value: python -m pytest -q tests/test_mcp_audit_followup.py -k sdk_profile
---

# SDK profile routing

Select a profile from observed dependency and source evidence, never from a filename or class nickname.

| Package evidence | Import/API evidence | Profile |
| --- | --- | --- |
| `mcp` | `mcp.server.mcpserver`, `MCPServer`, official transports | `python-official-mcp-sdk` |
| `fastmcp` | `from fastmcp ...`, FastMCP providers/auth/middleware | `python-fastmcp-package` |
| `ModelContextProtocol*` | official .NET hosting/client APIs | `dotnet-official-mcp-sdk` |
| conflicting or unknown | mixed private APIs, unrecognized fork, unsupported version | `unsupported-sdk-profile` |

Record package name, exact version, lockfile identity, imports, registration calls, transport construction, auth context extraction, and public extension points. A package-name match without import/API match is insufficient. Mixed profiles require an explicit adapter boundary and separate evidence per profile.
'''
write(MCP / "references/sdk-profile-routing.md", ROUTING)

# Add mandatory routing to the current SKILL workflow and reference index.
skill_path = MCP / "SKILL.md"
skill = skill_path.read_text(encoding="utf-8")
for number in range(17, 3, -1):
    skill = skill.replace(f"\n{number}. ", f"\n{number + 1}. ", 1)
route_target = "3. For a new server, generate a baseline with `tools/generate_python_server.py` or `tools/generate_dotnet_server.py`, then replace the sample domain and transport policy with the real deployment contract."
if route_target not in skill:
    raise RuntimeError("SKILL workflow insertion point missing")
skill = skill.replace(
    route_target,
    "3. Resolve the SDK profile from package name, exact version, imports, registration API, transport construction, and auth-context APIs using `references/sdk-profile-routing.md`. Record `unsupported-sdk-profile` plus a blocking waiver when no supported profile matches. Then choose the target maturity level.\n4. For a new server, generate a baseline with `tools/generate_python_server.py` or `tools/generate_dotnet_server.py`, then replace the sample domain and transport policy with the real deployment contract.",
    1,
)
reference_marker = "## Generated baselines\n"
reference_section = "## SDK profile routing\n\n- [SDK profile routing](references/sdk-profile-routing.md)\n- [Python official MCP SDK](references/python-official-mcp-sdk.md)\n- [Python FastMCP package](references/python-fastmcp-package.md)\n\n"
if reference_marker not in skill:
    raise RuntimeError("SKILL reference insertion point missing")
skill = skill.replace(reference_marker, reference_section + reference_marker, 1)
skill_path.write_text(skill, encoding="utf-8", newline="\n")

# Canonical repository-side CLI validator. It validates YAML/JSON documents and
# performs cross-field checks shared by generated Python and .NET tests.
VALIDATOR = '''\
#!/usr/bin/env python3
"""Validate MCP capability manifest documents against the canonical contract."""

from __future__ import annotations

import argparse
import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import yaml

SCHEMA_PATH = Path(__file__).with_name("mcp-capability-manifest.schema.json")


def _load(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    return json.loads(text) if path.suffix.casefold() == ".json" else yaml.safe_load(text)


def validate_manifest(value: Any) -> list[str]:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        return ["manifest must be a mapping"]
    required = set(schema["required"])
    errors: list[str] = []
    missing = sorted(required - set(value))
    unknown = sorted(set(value) - set(schema["properties"]))
    if missing:
        errors.append(f"missing fields: {missing}")
    if unknown:
        errors.append(f"unknown fields: {unknown}")
    if errors:
        return errors
    for name, definition in schema["properties"].items():
        item = value[name]
        if "enum" in definition and item not in definition["enum"]:
            errors.append(f"{name}: unsupported value {item!r}")
        if definition.get("type") == "boolean" and type(item) is not bool:
            errors.append(f"{name}: must be boolean")
        if definition.get("type") == "integer" and (type(item) is not int or item < definition.get("minimum", item)):
            errors.append(f"{name}: invalid integer")
    if value.get("retryable") and (not value.get("idempotent") or not value.get("retry_conditions")):
        errors.append("retryable requires idempotency and explicit retry_conditions")
    if value.get("concurrent_safe") is False and value.get("concurrency_scope") == "none":
        errors.append("concurrent_safe=false requires a conflict scope")
    if value.get("concurrent_safe") is False and value.get("concurrency_scope") == "global" and value.get("max_concurrency_per_scope") != 1:
        errors.append("global unsafe operation must serialize per scope")
    per_scope = value.get("max_concurrency_per_scope")
    global_limit = value.get("max_concurrency_global")
    if type(per_scope) is int and type(global_limit) is int and per_scope > global_limit:
        errors.append("max_concurrency_per_scope exceeds max_concurrency_global")
    if value.get("side_effects") == "destructive" and not value.get("requires_confirmation"):
        errors.append("destructive operation requires confirmation")
    if not isinstance(value.get("target_binding"), str) or not value["target_binding"].strip():
        errors.append("target_binding must be non-empty")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    raw = _load(args.manifest)
    manifests = raw if isinstance(raw, list) else raw.get("manifests", raw) if isinstance(raw, Mapping) else raw
    values = manifests if isinstance(manifests, list) else [manifests]
    findings: list[str] = []
    for index, value in enumerate(values):
        findings.extend(f"manifest[{index}]: {error}" for error in validate_manifest(value))
    for finding in findings:
        print(f"ERROR: {finding}")
    print(f"validated {len(values)} manifest(s); findings: {len(findings)}")
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
'''
write("contracts/mcp_capability_manifest.py", VALIDATOR)

# workflow_run is privileged-by-default. Require the complete trust predicate and
# exact run-id artifact binding whenever a workflow_run job has write permissions.
AUDITOR = ROOT / "skills/ci-cd-architect/tools/check_github_actions_policy_impl.py"
auditor = AUDITOR.read_text(encoding="utf-8")
insert_after = '''\
def _scalar_strings(value: Any) -> Iterator[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from _scalar_strings(key)
            yield from _scalar_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from _scalar_strings(item)
'''
workflow_helpers = insert_after + '''\

_WORKFLOW_RUN_REQUIRED_TERMS = (
    "github.event.workflow_run.conclusion == 'success'",
    "github.event.workflow_run.event == 'push'",
    "github.event.workflow_run.head_repository.full_name == github.repository",
)


def _workflow_run_write_findings(path: Path, job_name: str, job: dict[Any, Any]) -> list[Finding]:
    findings: list[Finding] = []
    condition = job.get("if")
    if not isinstance(condition, str):
        return [Finding(path, f"job {job_name!r} workflow_run write job requires an explicit trust condition")]
    normalized = " ".join(condition.replace('"', "'").split())
    for term in _WORKFLOW_RUN_REQUIRED_TERMS:
        if term not in normalized:
            findings.append(Finding(path, f"job {job_name!r} workflow_run write condition must include {term}"))
    steps = job.get("steps", [])
    if not isinstance(steps, list):
        return findings
    if not any("github.event.workflow_run.head_sha" in value for value in _scalar_strings(job)):
        findings.append(Finding(path, f"job {job_name!r} workflow_run write job must bind github.event.workflow_run.head_sha"))
    for index, step in enumerate(steps, start=1):
        if not isinstance(step, dict) or not isinstance(step.get("uses"), str):
            continue
        action = step["uses"].rsplit("@", 1)[0]
        if action != "actions/download-artifact":
            continue
        with_block = step.get("with")
        if not isinstance(with_block, dict) or with_block.get("run-id") != "${{ github.event.workflow_run.id }}":
            findings.append(Finding(path, f"job {job_name!r} step {index} workflow_run artifact must bind run-id to github.event.workflow_run.id"))
    return findings
'''
if "_WORKFLOW_RUN_REQUIRED_TERMS" not in auditor:
    if insert_after not in auditor:
        raise RuntimeError("auditor scalar helper block missing")
    auditor = auditor.replace(insert_after, workflow_helpers)
needle = '''\
        if write_job and selected_profile == "protected-release":
            if not isinstance(job.get("environment"), (str, dict)):
'''
replacement = '''\
        if write_job and "workflow_run" in event_names:
            findings.extend(_workflow_run_write_findings(path, str(job_name), job))
        if write_job and selected_profile == "protected-release":
            if not isinstance(job.get("environment"), (str, dict)):
'''
if needle not in auditor:
    raise RuntimeError("auditor protected release block missing")
auditor = auditor.replace(needle, replacement)
AUDITOR.write_text(auditor, encoding="utf-8", newline="\n")

# Update meta-tests for canonical templates, schemas, exact process/container smoke,
# workflow audit, SDK routing, and workflow_run trust conditions.
test_path = ROOT / "tests/test_mcp_generator.py"
test_text = test_path.read_text(encoding="utf-8")
test_text = test_text.replace(
    '        Path(".github/workflows/ci.yml"),',
    '        Path(".github/workflows/ci.yml"),\n        Path(".github/workflow-policy.yaml"),',
)
test_text = test_text.replace(
    '        Path("src/inventory_mcp/manifests.py"),',
    '        Path("src/inventory_mcp/manifests.py"),\n        Path("src/inventory_mcp/mcp-capability-manifest.schema.json"),',
)
test_text = test_text.replace(
    '        Path("tests/test_mcp_smoke.py"),',
    '        Path("tests/test_mcp_smoke.py"),\n        Path("tests/test_process_transport_smoke.py"),\n        Path("tests/smoke_exact_container.py"),',
)
test_text = test_text.replace(
    '    assert "Verify container wheel identity" in workflow',
    '    assert "Verify container wheel identity" in workflow\n    assert "Smoke exact container over stdio and Streamable HTTP" in workflow\n    assert "runs-on: ubuntu-24.04" in workflow\n    assert "ubuntu-latest" not in workflow\n    assert "concurrency:" in workflow\n    assert "cancel-in-progress: true" in workflow',
)
test_path.write_text(test_text, encoding="utf-8", newline="\n")

FOLLOWUP_TESTS = """\
"Regression tests for the post-migration MCP and CI contracts."

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_sdk_profiles_are_package_specific_and_routed() -> None:
    references = ROOT / "skills/mcp-server-architect/references"
    assert not (references / "python-fastmcp.md").exists()
    official = (references / "python-official-mcp-sdk.md").read_text(encoding="utf-8")
    external = (references / "python-fastmcp-package.md").read_text(encoding="utf-8")
    routing = (references / "sdk-profile-routing.md").read_text(encoding="utf-8")
    assert "official" in official.casefold() and "separately" in official.casefold()
    assert "unsupported-sdk-profile" in external
    assert "package name" in routing.casefold() and "import" in routing.casefold()


def test_python_generator_has_one_canonical_template_owner(tmp_path: Path) -> None:
    facade = (ROOT / "skills/mcp-server-architect/tools/generate_python_server.py").read_text(encoding="utf-8")
    implementation = (ROOT / "skills/mcp-server-architect/tools/generate_python_server_impl.py").read_text(encoding="utf-8")
    assert "_replace_required" not in facade
    assert "_BASE_PROJECT_FILES" not in facade
    assert "TEMPLATE_ROOT" in implementation
    generator = _load(ROOT / "skills/mcp-server-architect/tools/generate_python_server.py", "canonical_generator")
    target = tmp_path / "generated"
    generator.generate_project(target, "inventory_mcp", "Inventory MCP")
    workflow = target / ".github/workflows/ci.yml"
    auditor = _load(ROOT / "skills/ci-cd-architect/tools/check_github_actions_policy.py", "workflow_auditor")
    assert auditor.audit_workflow(workflow, target) == []


def test_manifest_schema_matches_generated_python_contract() -> None:
    schema = json.loads((ROOT / "contracts/mcp-capability-manifest.schema.json").read_text(encoding="utf-8"))
    required = set(schema["required"])
    assert {"risk", "determinism", "latency", "impact", "active_state", "max_response_bytes"} <= required
    source = next((ROOT / "skills/mcp-server-architect/tools/python-template/src").rglob("manifests.py.template")).read_text(encoding="utf-8")
    for field in required:
        assert f"    {field}:" in source


def _workflow_run_document(condition: str, run_id: str = "${{ github.event.workflow_run.id }}") -> str:
    return f'''# ai-skills-policy-profile: protected-release
name: Release
on:
  workflow_run:
    workflows: [CI]
    types: [completed]
permissions:
  contents: read
concurrency:
  group: release
  cancel-in-progress: false
jobs:
  validate:
    runs-on: ubuntu-24.04
    timeout-minutes: 10
    steps:
      - run: echo ok
  publish:
    needs: validate
    if: {condition}
    environment: release
    env:
      SOURCE_SHA: ${{{{ github.event.workflow_run.head_sha }}}}
    permissions:
      contents: read
      packages: write
    runs-on: ubuntu-24.04
    timeout-minutes: 10
    steps:
      - uses: actions/download-artifact@95815c38cf2ff2164869cbab79da8d1f422bc89e
        with:
          run-id: {run_id}
          github-token: ${{{{ github.token }}}}
      - run: echo publish
'''


def test_workflow_run_write_jobs_require_complete_trust_and_run_binding(tmp_path: Path) -> None:
    auditor = _load(ROOT / "skills/ci-cd-architect/tools/check_github_actions_policy.py", "workflow_run_auditor")
    workflow = tmp_path / ".github/workflows/release.yml"
    workflow.parent.mkdir(parents=True)
    complete = "${{ github.event.workflow_run.conclusion == 'success' && github.event.workflow_run.event == 'push' && github.event.workflow_run.head_repository.full_name == github.repository }}"
    workflow.write_text(_workflow_run_document(complete), encoding="utf-8")
    assert auditor.audit_workflow(workflow, tmp_path) == []
    workflow.write_text(_workflow_run_document("${{ github.event.workflow_run.conclusion == 'success' }}"), encoding="utf-8")
    messages = [finding.message for finding in auditor.audit_workflow(workflow, tmp_path)]
    assert any("event == 'push'" in message for message in messages)
    assert any("head_repository.full_name" in message for message in messages)
    workflow.write_text(_workflow_run_document(complete).replace("      SOURCE_SHA: ${{ github.event.workflow_run.head_sha }}\n", ""), encoding="utf-8")
    messages = [finding.message for finding in auditor.audit_workflow(workflow, tmp_path)]
    assert any("head_sha" in message for message in messages)
    workflow.write_text(_workflow_run_document(complete, "123"), encoding="utf-8")
    messages = [finding.message for finding in auditor.audit_workflow(workflow, tmp_path)]
    assert any("run-id" in message for message in messages)
"""
write("tests/test_mcp_audit_followup.py", FOLLOWUP_TESTS)

# Add new typed contract modules to quality gates.
quality = ROOT / "scripts/quality_targets.py"
q = quality.read_text(encoding="utf-8")
q = q.replace(
    '    "contracts/evidence.py",\n',
    '    "contracts/evidence.py",\n    "contracts/mcp_capability_manifest.py",\n',
)
q = q.replace(
    '    "contracts/rule_applicability.py",\n',
    '    "contracts/rule_applicability.py",\n    "contracts/mcp_capability_manifest.py",\n',
    1,
)
quality.write_text(q, encoding="utf-8", newline="\n")


# Update platform tests to preserve OS seams while proving string patch helpers are gone.
platform_test = ROOT / "tests/test_generator_platform_contracts.py"
platform_text = platform_test.read_text(encoding="utf-8")
old_test = """
def test_python_generator_facade_rejects_missing_or_ambiguous_contract_fragments(tmp_path: Path, monkeypatch) -> None:
    facade = load(PYTHON_GENERATOR, "python_generator_facade_contract")
    monkeypatch.setattr(facade, "_LOCK_ROOT", tmp_path)
    with pytest.raises(RuntimeError, match="missing reviewed dependency contract"):
        facade._read_contract_file("missing.lock")
    with pytest.raises(RuntimeError, match="expected exactly one"):
        facade._replace_required("old old", "old", "new", file_name="test")
"""
new_test = """
def test_python_generator_facade_has_no_string_patching_contract() -> None:
    facade = load(PYTHON_GENERATOR, "python_generator_facade_contract")
    assert not hasattr(facade, "_replace_required")
    assert not hasattr(facade, "_read_contract_file")
    assert facade._implementation.TEMPLATE_ROOT.is_dir()
"""
if old_test not in platform_text:
    raise RuntimeError("stale Python facade test block missing")
platform_test.write_text(platform_text.replace(old_test, new_test), encoding="utf-8", newline="\n")

# Skill manifest and standard references.
manifest = MCP / "manifest.yaml"
m = manifest.read_text(encoding="utf-8")
m = m.replace(
    "- references/protocol-and-sdk-compatibility.md\n",
    "- references/protocol-and-sdk-compatibility.md\n- references/sdk-profile-routing.md\n- references/python-official-mcp-sdk.md\n- references/python-fastmcp-package.md\n",
)
m = m.replace(
    "- tools/generate_python_server.py\n",
    "- tools/generate_python_server.py\n- tools/generate_python_server_impl.py\n- tools/python-template/.github/workflows/ci.yml.template\n",
)
manifest.write_text(m, encoding="utf-8", newline="\n")

standard = MCP / "STANDARD.md"
s = standard.read_text(encoding="utf-8")
s = s.replace(
    "- [Python official MCP SDK](references/python-official-mcp-sdk.md)",
    "- [SDK profile routing](references/sdk-profile-routing.md)\n- [Python official MCP SDK](references/python-official-mcp-sdk.md)\n- [Python FastMCP package](references/python-fastmcp-package.md)",
)
standard.write_text(s, encoding="utf-8", newline="\n")

# Changelog records only substantive user-facing changes.
changelog = ROOT / "CHANGELOG.md"
c = changelog.read_text(encoding="utf-8")
entry = """\n- Split Python SDK guidance into official `mcp` and external `fastmcp` profiles with deterministic package/import/API routing and an explicit unsupported profile.\n- Replaced Python generator string patching with one canonical final template tree, added canonical cross-language capability-manifest schema validation, final-payload limits, explicit concurrency scopes, and emitted installed-entrypoint plus exact-container stdio/HTTP smoke tests.\n- Hardened workflow auditing for privileged `workflow_run` trust predicates and exact source-run artifact binding.\n"""
marker = "## Unreleased\n"
if marker in c and "Split Python SDK guidance" not in c:
    c = c.replace(marker, marker + entry, 1)
changelog.write_text(c, encoding="utf-8", newline="\n")

print("phase 1 audit follow-up applied")
